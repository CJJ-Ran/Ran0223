# -*-coding:utf-8-*-
from django.http import HttpResponse
from django.shortcuts import render
from django.http import HttpResponseRedirect
from django.core.urlresolvers import reverse


def article(request):
    return render(request, 'Ran0223.html')


def article1(request):
    return render(request, 'python.html')


def article2(request):
    return render(request, 'django.html')






